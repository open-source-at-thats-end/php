<?php
namespace Aws\IoTSiteWise\Exception;

use Aws\Exception\AwsException;

/**
 * Represents an error interacting with the **AWS IoT SiteWise** service.
 */
class IoTSiteWiseException extends AwsException {}
